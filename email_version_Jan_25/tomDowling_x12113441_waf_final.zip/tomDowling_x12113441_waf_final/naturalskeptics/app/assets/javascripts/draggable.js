$(dragDiv);

//Functions
function dragDiv() {
    $('#cart').draggable();
    $('#userPicker').draggable();

}