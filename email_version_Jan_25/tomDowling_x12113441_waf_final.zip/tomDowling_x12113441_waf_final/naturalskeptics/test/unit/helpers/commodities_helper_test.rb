require 'test_helper'

class CommoditiesHelperTest < ActionView::TestCase
end
