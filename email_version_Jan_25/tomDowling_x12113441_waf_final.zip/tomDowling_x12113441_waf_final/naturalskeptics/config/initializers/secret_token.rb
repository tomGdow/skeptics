# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Naturalskeptics::Application.config.secret_token = 'fd3c3bb25ab0bae6bebf89c1c869bf6f09a008bcc2f3cebc0888feb15cac6048d043eeeb61cfeab2993eeb02641de69b172646dc3dadbc37df9bd945f7856dab'
