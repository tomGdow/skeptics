require 'test_helper'

class XmlusersHelperTest < ActionView::TestCase
end
