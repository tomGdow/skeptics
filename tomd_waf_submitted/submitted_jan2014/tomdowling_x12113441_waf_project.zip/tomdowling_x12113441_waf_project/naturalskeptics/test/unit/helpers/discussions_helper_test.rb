require 'test_helper'

class DiscussionsHelperTest < ActionView::TestCase
end
