require 'test_helper'

class JscalcHelperTest < ActionView::TestCase
end
