module JscalcHelper
end
